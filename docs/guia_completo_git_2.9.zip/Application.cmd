start loader.exe sdx.o
